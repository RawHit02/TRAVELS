# flipcard-tut
 Flipcard tutorial in HTML and CSS

[Live Preview](https://htmlpreview.github.io/?https://github.com/russs123/flipcard-tut/blob/main/index.html)
